# Ant-WebProject

Once you run the ant command, it will generate the jar file.

Run the jar file as follows.
# java -jar <<Path to Jar file>>/HelloWorld-20170629.jar

Note: In MAC or Linuc before running java, give the execute permissions as follows.
#chmod -R 777 <<Path to Jar file>>/HelloWorld-20170629.jar

